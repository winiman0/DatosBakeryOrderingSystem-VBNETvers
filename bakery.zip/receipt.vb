﻿Public Class receipt
    Private Sub lstReceipt_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstReceipt.SelectedIndexChanged

    End Sub
End Class