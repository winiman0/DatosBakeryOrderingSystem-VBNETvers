﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblRPPrice = New System.Windows.Forms.Label()
        Me.lblWafflePrice = New System.Windows.Forms.Label()
        Me.rdnMilkDonut = New System.Windows.Forms.RadioButton()
        Me.rdnRaspberryPie = New System.Windows.Forms.RadioButton()
        Me.rdnWaffle = New System.Windows.Forms.RadioButton()
        Me.rdnCreampuff = New System.Windows.Forms.RadioButton()
        Me.lblCreampuffPrice = New System.Windows.Forms.Label()
        Me.lblNCPrice = New System.Windows.Forms.Label()
        Me.lblFBCPrice = New System.Windows.Forms.Label()
        Me.lblCWCPrice = New System.Windows.Forms.Label()
        Me.rdnNC = New System.Windows.Forms.RadioButton()
        Me.rdnFBC = New System.Windows.Forms.RadioButton()
        Me.rdnCWC = New System.Windows.Forms.RadioButton()
        Me.rdnJMC = New System.Windows.Forms.RadioButton()
        Me.lblJMCPrice = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCart = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductToolStripMenuItem, Me.CartToolStripMenuItem, Me.AccountToolStripMenuItem, Me.LogOutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1114, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.ProductToolStripMenuItem.Text = "Product"
        '
        'CartToolStripMenuItem
        '
        Me.CartToolStripMenuItem.Name = "CartToolStripMenuItem"
        Me.CartToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.CartToolStripMenuItem.Text = "Cart"
        '
        'AccountToolStripMenuItem
        '
        Me.AccountToolStripMenuItem.Name = "AccountToolStripMenuItem"
        Me.AccountToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.AccountToolStripMenuItem.Text = "Account"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.RosyBrown
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1114, 617)
        Me.Panel1.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.MistyRose
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Controls.Add(Me.PictureBox3)
        Me.Panel3.Controls.Add(Me.PictureBox6)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.lblRPPrice)
        Me.Panel3.Controls.Add(Me.lblWafflePrice)
        Me.Panel3.Controls.Add(Me.rdnMilkDonut)
        Me.Panel3.Controls.Add(Me.rdnRaspberryPie)
        Me.Panel3.Controls.Add(Me.rdnWaffle)
        Me.Panel3.Controls.Add(Me.rdnCreampuff)
        Me.Panel3.Controls.Add(Me.PictureBox8)
        Me.Panel3.Controls.Add(Me.lblCreampuffPrice)
        Me.Panel3.Controls.Add(Me.PictureBox7)
        Me.Panel3.Controls.Add(Me.PictureBox5)
        Me.Panel3.Controls.Add(Me.PictureBox4)
        Me.Panel3.Controls.Add(Me.lblNCPrice)
        Me.Panel3.Controls.Add(Me.lblFBCPrice)
        Me.Panel3.Controls.Add(Me.lblCWCPrice)
        Me.Panel3.Controls.Add(Me.rdnNC)
        Me.Panel3.Controls.Add(Me.rdnFBC)
        Me.Panel3.Controls.Add(Me.rdnCWC)
        Me.Panel3.Controls.Add(Me.rdnJMC)
        Me.Panel3.Controls.Add(Me.PictureBox1)
        Me.Panel3.Controls.Add(Me.lblJMCPrice)
        Me.Panel3.Location = New System.Drawing.Point(47, 63)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1010, 478)
        Me.Panel3.TabIndex = 35
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(817, 388)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "RM 4.90"
        '
        'lblRPPrice
        '
        Me.lblRPPrice.AutoSize = True
        Me.lblRPPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRPPrice.Location = New System.Drawing.Point(602, 388)
        Me.lblRPPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblRPPrice.Name = "lblRPPrice"
        Me.lblRPPrice.Size = New System.Drawing.Size(68, 17)
        Me.lblRPPrice.TabIndex = 49
        Me.lblRPPrice.Text = "RM 8.90"
        '
        'lblWafflePrice
        '
        Me.lblWafflePrice.AutoSize = True
        Me.lblWafflePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWafflePrice.Location = New System.Drawing.Point(380, 388)
        Me.lblWafflePrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblWafflePrice.Name = "lblWafflePrice"
        Me.lblWafflePrice.Size = New System.Drawing.Size(68, 17)
        Me.lblWafflePrice.TabIndex = 48
        Me.lblWafflePrice.Text = "RM 4.50"
        '
        'rdnMilkDonut
        '
        Me.rdnMilkDonut.AutoSize = True
        Me.rdnMilkDonut.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnMilkDonut.Location = New System.Drawing.Point(802, 408)
        Me.rdnMilkDonut.Name = "rdnMilkDonut"
        Me.rdnMilkDonut.Size = New System.Drawing.Size(92, 21)
        Me.rdnMilkDonut.TabIndex = 47
        Me.rdnMilkDonut.TabStop = True
        Me.rdnMilkDonut.Text = "Milk Donut"
        Me.rdnMilkDonut.UseVisualStyleBackColor = True
        '
        'rdnRaspberryPie
        '
        Me.rdnRaspberryPie.AutoSize = True
        Me.rdnRaspberryPie.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnRaspberryPie.Location = New System.Drawing.Point(577, 408)
        Me.rdnRaspberryPie.Name = "rdnRaspberryPie"
        Me.rdnRaspberryPie.Size = New System.Drawing.Size(116, 21)
        Me.rdnRaspberryPie.TabIndex = 46
        Me.rdnRaspberryPie.TabStop = True
        Me.rdnRaspberryPie.Text = "Raspberry Pie"
        Me.rdnRaspberryPie.UseVisualStyleBackColor = True
        '
        'rdnWaffle
        '
        Me.rdnWaffle.AutoSize = True
        Me.rdnWaffle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnWaffle.Location = New System.Drawing.Point(382, 408)
        Me.rdnWaffle.Name = "rdnWaffle"
        Me.rdnWaffle.Size = New System.Drawing.Size(66, 21)
        Me.rdnWaffle.TabIndex = 45
        Me.rdnWaffle.TabStop = True
        Me.rdnWaffle.Text = "Waffle"
        Me.rdnWaffle.UseVisualStyleBackColor = True
        '
        'rdnCreampuff
        '
        Me.rdnCreampuff.AutoSize = True
        Me.rdnCreampuff.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnCreampuff.Location = New System.Drawing.Point(145, 408)
        Me.rdnCreampuff.Name = "rdnCreampuff"
        Me.rdnCreampuff.Size = New System.Drawing.Size(91, 21)
        Me.rdnCreampuff.TabIndex = 44
        Me.rdnCreampuff.TabStop = True
        Me.rdnCreampuff.Text = "Creampuff"
        Me.rdnCreampuff.UseVisualStyleBackColor = True
        '
        'lblCreampuffPrice
        '
        Me.lblCreampuffPrice.AutoSize = True
        Me.lblCreampuffPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCreampuffPrice.Location = New System.Drawing.Point(159, 388)
        Me.lblCreampuffPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCreampuffPrice.Name = "lblCreampuffPrice"
        Me.lblCreampuffPrice.Size = New System.Drawing.Size(68, 17)
        Me.lblCreampuffPrice.TabIndex = 43
        Me.lblCreampuffPrice.Text = "RM 5.90"
        '
        'lblNCPrice
        '
        Me.lblNCPrice.AutoSize = True
        Me.lblNCPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNCPrice.Location = New System.Drawing.Point(808, 169)
        Me.lblNCPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNCPrice.Name = "lblNCPrice"
        Me.lblNCPrice.Size = New System.Drawing.Size(77, 17)
        Me.lblNCPrice.TabIndex = 38
        Me.lblNCPrice.Text = "RM 55.50"
        '
        'lblFBCPrice
        '
        Me.lblFBCPrice.AutoSize = True
        Me.lblFBCPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFBCPrice.Location = New System.Drawing.Point(602, 169)
        Me.lblFBCPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblFBCPrice.Name = "lblFBCPrice"
        Me.lblFBCPrice.Size = New System.Drawing.Size(77, 17)
        Me.lblFBCPrice.TabIndex = 37
        Me.lblFBCPrice.Text = "RM 78.50"
        '
        'lblCWCPrice
        '
        Me.lblCWCPrice.AutoSize = True
        Me.lblCWCPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCWCPrice.Location = New System.Drawing.Point(371, 169)
        Me.lblCWCPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCWCPrice.Name = "lblCWCPrice"
        Me.lblCWCPrice.Size = New System.Drawing.Size(77, 17)
        Me.lblCWCPrice.TabIndex = 36
        Me.lblCWCPrice.Text = "RM 84.90"
        '
        'rdnNC
        '
        Me.rdnNC.AutoSize = True
        Me.rdnNC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnNC.Location = New System.Drawing.Point(791, 189)
        Me.rdnNC.Name = "rdnNC"
        Me.rdnNC.Size = New System.Drawing.Size(116, 21)
        Me.rdnNC.TabIndex = 35
        Me.rdnNC.TabStop = True
        Me.rdnNC.Text = "Nightsky Cake"
        Me.rdnNC.UseVisualStyleBackColor = True
        '
        'rdnFBC
        '
        Me.rdnFBC.AutoSize = True
        Me.rdnFBC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnFBC.Location = New System.Drawing.Point(571, 189)
        Me.rdnFBC.Name = "rdnFBC"
        Me.rdnFBC.Size = New System.Drawing.Size(132, 21)
        Me.rdnFBC.TabIndex = 34
        Me.rdnFBC.TabStop = True
        Me.rdnFBC.Text = "Fruity Bites Cake"
        Me.rdnFBC.UseVisualStyleBackColor = True
        '
        'rdnCWC
        '
        Me.rdnCWC.AutoSize = True
        Me.rdnCWC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnCWC.Location = New System.Drawing.Point(331, 189)
        Me.rdnCWC.Name = "rdnCWC"
        Me.rdnCWC.Size = New System.Drawing.Size(164, 21)
        Me.rdnCWC.TabIndex = 33
        Me.rdnCWC.TabStop = True
        Me.rdnCWC.Text = "Confenti Wanilla Cake"
        Me.rdnCWC.UseVisualStyleBackColor = True
        '
        'rdnJMC
        '
        Me.rdnJMC.AutoSize = True
        Me.rdnJMC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdnJMC.Location = New System.Drawing.Point(93, 189)
        Me.rdnJMC.Name = "rdnJMC"
        Me.rdnJMC.Size = New System.Drawing.Size(174, 21)
        Me.rdnJMC.TabIndex = 32
        Me.rdnJMC.TabStop = True
        Me.rdnJMC.Text = "Japanese Matcha Cake"
        Me.rdnJMC.UseVisualStyleBackColor = True
        '
        'lblJMCPrice
        '
        Me.lblJMCPrice.AutoSize = True
        Me.lblJMCPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJMCPrice.Location = New System.Drawing.Point(142, 169)
        Me.lblJMCPrice.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblJMCPrice.Name = "lblJMCPrice"
        Me.lblJMCPrice.Size = New System.Drawing.Size(77, 17)
        Me.lblJMCPrice.TabIndex = 24
        Me.lblJMCPrice.Text = "RM 79.90"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(42, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(139, 29)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "PRODUCT"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnCart)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 546)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1114, 71)
        Me.Panel2.TabIndex = 0
        '
        'btnCart
        '
        Me.btnCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCart.Location = New System.Drawing.Point(964, 18)
        Me.btnCart.Name = "btnCart"
        Me.btnCart.Size = New System.Drawing.Size(93, 32)
        Me.btnCart.TabIndex = 1
        Me.btnCart.Text = "Add to Cart"
        Me.btnCart.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox2.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.milkDonut
        Me.PictureBox2.Location = New System.Drawing.Point(791, 247)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 53
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox3.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.respberryPie
        Me.PictureBox3.Location = New System.Drawing.Point(578, 247)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 52
        Me.PictureBox3.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox6.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.sofwaffle
        Me.PictureBox6.Location = New System.Drawing.Point(351, 247)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox6.TabIndex = 51
        Me.PictureBox6.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox8.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.creamPuff
        Me.PictureBox8.Location = New System.Drawing.Point(124, 245)
        Me.PictureBox8.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 42
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox7.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.nightSkyCake
        Me.PictureBox7.Location = New System.Drawing.Point(791, 28)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox7.TabIndex = 41
        Me.PictureBox7.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox5.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.fruityBitesCake
        Me.PictureBox5.Location = New System.Drawing.Point(578, 28)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox5.TabIndex = 40
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox4.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.confetiVanillaCake
        Me.PictureBox4.Location = New System.Drawing.Point(351, 28)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox4.TabIndex = 39
        Me.PictureBox4.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.ErrorImage = Global.DatosBakeryOrderingSystem.My.Resources.Resources.removeBackground
        Me.PictureBox1.Image = Global.DatosBakeryOrderingSystem.My.Resources.Resources.japaneseMatchaCake
        Me.PictureBox1.Location = New System.Drawing.Point(124, 28)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(115, 139)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'ProductList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1114, 641)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "ProductList"
        Me.Text = "Product"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ProductToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CartToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AccountToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnCart As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents rdnJMC As RadioButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblJMCPrice As Label
    Friend WithEvents rdnNC As RadioButton
    Friend WithEvents rdnFBC As RadioButton
    Friend WithEvents rdnCWC As RadioButton
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents lblNCPrice As Label
    Friend WithEvents lblFBCPrice As Label
    Friend WithEvents lblCWCPrice As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblRPPrice As Label
    Friend WithEvents lblWafflePrice As Label
    Friend WithEvents rdnMilkDonut As RadioButton
    Friend WithEvents rdnRaspberryPie As RadioButton
    Friend WithEvents rdnWaffle As RadioButton
    Friend WithEvents rdnCreampuff As RadioButton
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents lblCreampuffPrice As Label
    Friend WithEvents PictureBox7 As PictureBox
End Class
